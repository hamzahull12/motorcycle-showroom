/**
 * @param {import('node-pg-migrate').MigrationBuilder} pgm
 */
export const up = (pgm) => {
  // ==========================================
  // 1. SEED USERS
  // ==========================================

  pgm.sql(`
    INSERT INTO users (
      id,
      username,
      email,
      password_hash,
      role,
      is_active
    )
    VALUES
      (
        uuid_generate_v4(),
        'admin',
        'admin@showroom.test',
        '$2b$12$0/0.BU0E/FPLkzv9TrIEneP6RYFCLTeFLm4xE34umP48rWxCsOyRi',
        'admin',
        true
      ),
      (
        uuid_generate_v4(),
        'staff',
        'staff@showroom.test',
        '$2b$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW',
        'staff',
        true
      )
    ON CONFLICT (username) DO NOTHING;
  `);

  // ==========================================
  // 2. SEED BRANDS
  // ==========================================

  pgm.sql(`
    INSERT INTO brands (name, slug)
    VALUES
      ('Honda', 'honda'),
      ('Yamaha', 'yamaha'),
      ('Suzuki', 'suzuki'),
      ('Kawasaki', 'kawasaki')
    ON CONFLICT (slug) DO NOTHING;
  `);

  // ==========================================
  // 3. SEED MOTORCYCLES
  // ==========================================

  pgm.sql(`
    INSERT INTO motorcycles (
      brand_id,
      title,
      slug,
      category,
      engine_stroke,
      transmission,
      engine_capacity_cc,
      color,
      year,
      mileage_km,
      price,
      tax_expired_at,
      status,
      location,
      description
    )
    VALUES
      (
        (SELECT id FROM brands WHERE slug = 'honda'),
        'Honda Vario 160 ABS',
        'honda-vario-160-abs',
        'matic',
        '4_tak',
        'matic',
        160,
        'Matte Black',
        2023,
        12000,
        25000000,
        '2027-06-15',
        'available',
        'Showroom Utama',
        'Honda Vario 160 ABS bekas dengan kondisi sangat baik dan siap digunakan.'
      ),
      (
        (SELECT id FROM brands WHERE slug = 'yamaha'),
        'Yamaha NMAX 155 Connected',
        'yamaha-nmax-155-connected',
        'matic',
        '4_tak',
        'matic',
        155,
        'Black',
        2022,
        18000,
        28500000,
        '2026-11-20',
        'available',
        'Showroom Utama',
        'Yamaha NMAX 155 Connected dengan kondisi terawat dan dokumen lengkap.'
      ),
      (
        (SELECT id FROM brands WHERE slug = 'suzuki'),
        'Suzuki GSX-R150',
        'suzuki-gsx-r150',
        'sport',
        '4_tak',
        'manual',
        150,
        'Blue',
        2021,
        15000,
        22000000,
        '2026-09-10',
        'reserved',
        'Showroom Utama',
        'Suzuki GSX-R150 dengan performa baik dan kondisi siap pakai.'
      )
    ON CONFLICT (slug) DO NOTHING;
  `);

  // ==========================================
  // 4. SEED MOTORCYCLE IMAGES
  // ==========================================

  pgm.sql(`
    INSERT INTO motorcycle_images (
      motorcycle_id,
      image_url,
      is_primary,
      sort_order
    )
    VALUES
      (
        (
          SELECT id
          FROM motorcycles
          WHERE slug = 'honda-vario-160-abs'
        ),
        'https://ik.imagekit.io/zlt25mb52fx/tr:q-70,pr-true/uploads/article/thumbnail/imageupload-2576-10082023-022210.jpeg',
        true,
        0
      ),
      (
        (
          SELECT id
          FROM motorcycles
          WHERE slug = 'honda-vario-160-abs'
        ),
        'https://cdn.antaranews.com/cache/1200x800/2024/01/17/WhatsApp-Image-2024-01-17-at-10.15.34.jpeg',
        false,
        1
      ),
      (
        (
          SELECT id
          FROM motorcycles
          WHERE slug = 'yamaha-nmax-155-connected'
        ),
        'https://imgcdnblog.carbay.com/wp-content/uploads/2022/02/02111927/Yamaha-NMax-STD-Red.jpg',
        true,
        0
      ),
      (
        (
          SELECT id
          FROM motorcycles
          WHERE slug = 'suzuki-gsx-r150'
        ),
        'https://imgcdn.oto.com/large/gallery/exterior/92/1579/suzuki-gsx-r150-slant-rear-view-full-image-779279.jpg',
        true,
        0
      );
  `);
};

/**
 * @param {import('node-pg-migrate').MigrationBuilder} pgm
 */
export const down = (pgm) => {
  pgm.sql(`
    DELETE FROM motorcycle_images
    WHERE motorcycle_id IN (
      SELECT id
      FROM motorcycles
      WHERE slug IN (
        'honda-vario-160-abs',
        'yamaha-nmax-155-connected',
        'suzuki-gsx-r150'
      )
    );
  `);

  pgm.sql(`
    DELETE FROM motorcycles
    WHERE slug IN (
      'honda-vario-160-abs',
      'yamaha-nmax-155-connected',
      'suzuki-gsx-r150'
    );
  `);

  pgm.sql(`
    DELETE FROM brands
    WHERE slug IN (
      'honda',
      'yamaha',
      'suzuki',
      'kawasaki'
    );
  `);

  pgm.sql(`
    DELETE FROM users
    WHERE username IN ('admin', 'staff');
  `);
};